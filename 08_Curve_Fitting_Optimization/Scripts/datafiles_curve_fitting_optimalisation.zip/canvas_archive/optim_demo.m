% Demonstration script for the linprog optimalisation function
% f is the goal function
% A contains boundary functions
% x contains the answer

f = [ -5; -4; -6]
A = [1 -1 1; 3 2 4; 3 2 0];
b = [20; 42; 30];
lb = zeros (3,1) ;
[x,fval,exitflag,output,lambda] = linprog(f,A,b,[],[],lb);

x