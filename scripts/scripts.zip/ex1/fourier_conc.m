function [x,t,c] = fourier_conc()

D = 1e-8;
L = 0.01;
t_end = 1000;
cx = linspace(0,L,100);
ct = linspace(0,t_end,100);

[x t] = meshgrid(cx,ct);
c = zeros(length(cx),length(ct));
curr = 0;

% Loop over positions and times
for nx = 1:length(cx)
    for nt = 1:length(ct)
        % Set difference and iterator
        diff = 1;
        n = 1;
        % Add terms until the difference is negligible
        while (abs(diff) > 1e-8) | (n < 10)
            prev = curr;
            
            % Compute current term
            curr = (4 * L * (-1)^(n+1))/(n*pi) * exp(-D*(n^2*pi^2)/(L^2) * ct(nt)) * sin((n*pi*cx(nx))/(L));
            
            % Add to sum
            c(nt,nx) = c(nt,nx) + curr;
            
            % Update difference between current and previous term
            diff = prev - curr;
            
            % Update iterator
            n = n + 1;
        end
    end
end

% Plot
waterfall(x,t,c);
colormap(hsv);
colorbar
xlabel('Position [m]');
ylabel('Time [s]');
zlabel('Concentration [mol/m3/s]');

 
end