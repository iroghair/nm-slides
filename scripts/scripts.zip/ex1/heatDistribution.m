function heatDistribution()

[x y] = meshgrid(-2.1:0.15:2.1, -6:0.15:6);
u = 80 * y.^2 .* myExponent(-x.^2 - 0.3*y.^2);

[dux duy] = gradient(u,0.03,0.03);
contourf(x,y,u);
colormap(hot); colorbar
hold on; axis equal; axis tight;

% Note the minus-sign, since the heat flux is going from high->low
quiver(x,y,-dux,-duy,2,'w');
end