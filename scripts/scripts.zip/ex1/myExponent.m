function ex = myExponent(x)
% x:    value to calculate the exponent of

% Some pre-work
ex = ones(size(x)); % The result, starting at 1

% Loop over all elements of x
for p = 1:size(x,1)
    for q = 1:size(x,2)
        n = 1;              % The counter, increased by 1 each loop
        term = 1;           % The term that is added
        % Loop until the new term is small enough
        while (abs(term) > 1e-6) % Note: use abs!
            term = (x(p,q)^n)/fact_recursive(n);
            ex(p,q) = ex(p,q) + term;
            n = n + 1;
        end
    end
end