function res = fact_for(x)

% Catch non-integer case
if (fix(x)~=x) | (x<0)
    disp 'You should provide a positive integer number only'
    return;
end

res = 1;

for i = 1:x
    res = res * i;
end

end