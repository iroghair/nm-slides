function out = mystery(a,b)
if (b == 1)
    % Base case
    out = a;
else 
    % Recursive function call
    out = a + mystery(a,b-1);
end
